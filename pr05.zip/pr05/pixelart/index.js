let matrix = [];
function initMatrix(n, m) {
  matrix = [];
  for(let i = 0; i<n; i++) {
    const row = [];
    for(let j = 0; j<m; j++) {
      row.push("#ffffff");
    }
    matrix.push(row)
  }
}

// Elements
const form = document.querySelector("form");
const inputWidth = document.querySelector("#width");
const inputHeight = document.querySelector("#height");
const divEditor = document.querySelector("#editor");

// Event listeners
form.addEventListener("submit", onGenerate);
function onGenerate(e) {
  e.preventDefault();
  // read input
  const w = parseInt(inputWidth.value);
  const h = parseInt(inputHeight.value);
  // processing
  initMatrix(h, w);
  // write output
  renderTable();
}
divEditor.addEventListener("click", onClick);
function onClick(e) {
  if (e.target.matches("td")) {
    // read i, j
    const j = e.target.cellIndex;
    const tr = e.target.parentNode;
    const i = tr.rowIndex;
    // processing
    matrix[i][j] = "#ff0000";
    // render
    renderTable();
  }
}

// Render
function renderTable() {
  divEditor.innerHTML = `
    <table class="edit">
      ${matrix.map(row => `
        <tr>
          ${row.map(color => `
            <td style="background-color: ${color}"></td>
          `).join("")}
        </tr>
      `).join("")}
    </table>
  `; 
}